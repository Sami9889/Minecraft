# Minecraft Server - Paper + GeyserMC + ViaVersion

Continuous Minecraft server with Bedrock support, auto-updates, and 24/7 operation on a self-hosted runner.

## Architecture

```
minecraft.sami-s.dev (DNS A: 100.89.76.72)
├── Port 25565/TCP - Java Edition (Paper)
└── Port 19132/UDP - Bedrock Edition (GeyserMC)
```

## Components

- **Paper 26.2** - High-performance Minecraft server (plugin support)
- **GeyserMC 2.11.1** - Bedrock to Java bridge
- **ViaVersion 5.11.0** - Protocol translation

## Connect

- **Java Edition**: `minecraft.sami-s.dev:25565`
- **Bedrock Edition**: `minecraft.sami-s.dev:19132`

## Setup

1. Set GitHub secret `IP` to `100.89.76.72`
2. Add a **self-hosted runner** on your server at `100.89.76.72`
3. Go to **Actions** → **Minecraft Server - Self Hosted** → **Run workflow**
4. Select **deploy** and click run

The workflow will:
- Download Paper 26.2 from PaperMC
- Download GeyserMC Spigot plugin
- Download ViaVersion plugin
- Configure `server.properties`
- Configure GeyserMC for Bedrock on port 19132
- Start the server with `./scripts/start.sh`

## Features

- **Auto-restart**: Server restarts automatically if it crashes
- **Auto-update**: Daily checks for new versions at 4:00 AM
- **Backup**: Automatic world backups before updates
- **24/7**: Runs on your self-hosted runner continuously
- **DNS Ready**: Configured for `minecraft.sami-s.dev`

## Required GitHub Secrets

Add these in repo Settings → Secrets and variables → Actions:

| Secret | Description |
|--------|-------------|
| `IP` | Your server public IP, e.g. `100.89.76.72` |

## DNS Configuration

Ensure your DNS points `minecraft.sami-s.dev` to `100.89.76.72`.

## File Structure

```
minecraft-server/
├── .github/workflows/
│   └── minecraft-server.yml    # GitHub Actions workflow
├── configs/
│   └── minecraft-server.service # Systemd unit
├── scripts/
│   ├── start.sh                 # Main server startup
│   ├── update.sh                # Version checker & updater
│   └── setup-backend.sh         # VPS full setup
├── server/
│   ├── paper.jar                # Paper server
│   ├── server.properties        # Server config
│   ├── eula.txt                 # EULA accepted
│   ├── world/                   # World data
│   └── plugins/
│       ├── Geyser-Spigot.jar    # Bedrock support
│       ├── ViaVersion.jar       # Protocol support
│       └── Geyser-Spigot/
│           └── config.yml       # Geyser config
└── README.md
```

## Management

```bash
# Start/Stop/Restart
sudo systemctl start minecraft-server
sudo systemctl stop minecraft-server
sudo systemctl restart minecraft-server

# Check status
sudo systemctl status minecraft-server

# View logs
journalctl -u minecraft-server -f

# Manual update
./scripts/update.sh update

# Backup world
./scripts/update.sh backup
```

## Auto-Update Schedule

- **Daily**: Checks for Paper, GeyserMC, ViaVersion updates at 4:00 AM
- **On Update**: Creates world backup, downloads new versions, restarts server
- **Logs**: `logs/updater.log`

## Requirements

- **Server**: Linux machine with 2GB+ RAM at `100.89.76.72`
- **Java**: OpenJDK 21 or Temurin 21
- **Network**: Port 25565/TCP and 19132/UDP open
- **DNS**: A record pointing `minecraft.sami-s.dev` to `100.89.76.72`

## Security

- Firewall configured for only required ports
- Online mode enabled (authenticated Minecraft accounts)
- Secure profile enforcement enabled

## License

By running this server you agree to:
- [Minecraft EULA](https://www.minecraft.net/eula)
- [Minecraft Privacy Policy](https://www.microsoft.com/privacy)
